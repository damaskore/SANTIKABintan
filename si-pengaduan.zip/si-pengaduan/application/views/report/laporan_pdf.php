<!DOCTYPE html>
<html><head>
    <title>Cetak Laporan Pengaduan</title>
    <style>
        body {
            font-family: arial, sans-serif;
            margin: 1cm 1cm 1cm 1cm;
        }

        h2 {
            margin-top: auto;
            text-align: center;
            position: fixed;
            left: 0px;
            right: 0px;
        }

        table {
            border-collapse: collapse;
            width: 100%;
            padding: 4px;
            text-align: center;
        }

        table, th, td {
            border: 1px solid black;
        }

    </style>
</head><body>
     <!-- <div style="text-align: center " margin-top: auto;>
     <h3>PEMERINTAH KABUPATEN BINTAN</h3><br>
     <h2>DINAS KOMUNIKASI DAN INFORMATIKA</h2><br>
     <h4>Jalan Raya Tanjungpinang - Tanjung Uban KM.42</h4><br>
     <h4>Email : kominfo@bintankab.go.id</h4>
     </div> -->
     
     <h2>DAFTAR LAPORAN PENGADUAN</h2>
    <div class="cetak">
        Tanggal di cetak : <?= date('d/m/Y'); ?>
    </div>

    <table>
        <tr>
            <th style="width: 6%">No.</th>
            <th style="width: 20%">Jenis Pelaporan</th>
            <th style="width: 40%">Isi Pengaduan</th>
            <th style="width: 14%">Tanggal Pengaduan</th>
            <th style="width: 20%">Nama Instansi</th>
            <!-- <th style="width: 20%">Keterangan</th> -->
            <th style="width: 20%">Status</th>
        </tr>

        <?php if (!empty($data)) : ?>
        <?php foreach($data as $num => $row) : ?>
        <tr>
            <td style="width: 6%"><?= $num+1 ?></td>
            <td style="width: 20%"><?= $row['judul_pengaduan']; ?></td>
            <td style="width: 40%"><?= $row['isi_pengaduan']; ?></td>
            <td style="width: 14%"><?= $row['tgl_pengaduan']; ?></td>
            <td style="width: 20%"><?= $row['nama_instansi']; ?></td>
            <!-- <td style="width: 20%">-</td> -->
            <td style="width: 20%" class="status"><?= $row['status_pengaduan'] == 0 ? '<span class="badge-warning p-1 rounded-sm">Belum Diproses</span>' : ($row['status_pengaduan'] == 1 ? '<span class="badge-blue p-1 rounded-sm">Proses</span>' : ($row['status_pengaduan'] == 2 ? '<span class="badge-success p-1 rounded-sm">Selesai</span>' : '<span class="badge-danger p-1 rounded-sm">Batal</span>')) ?></td>
        </tr>
        <?php endforeach; ?>
    <?php else : ?>
        <h3>Tidak ada data!</h3>
    <?php endif; ?>
    </table>
    <h3> Total : <?= count($data); ?>  Pengaduan</h3>
</body></html>
