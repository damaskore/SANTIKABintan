<!-- Begin Page Content -->
<div class="container-fluid">

    <div class="row mt-4">
        <div class="col-xl-10 col-lg-10 col-md-12 col-sm-12 col-xs-12">

            <h3 class="h3 text-gray-900"><i class="fa fa-fw fa-print"></i> Cetak Laporan Jumlah Pengaduan</h3>

            <div class="card shadow-sm my-3">
                <div class="card-body border-left-info rounded-sm text-justify">
                    <i class="fa fa-fw fa-info-circle fa-lg"></i> <strong> Silahkan pilih range tanggal untuk menemukan list data pengaduan yang ingin di cetak sebagai laporan.</strong>
                </div>
            </div>

        </div>
        <!-- .col -->
    </div>
    <!-- .row -->

    <div class="row">
        <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-xs-12">
            <form action="<?= base_url('menu/cetak_laporan2') ?>" method="post">
                <div class="form-row">
                    <div class="col-xl-3 col-lg-3 col-md-3 col-sm-12 col-xs-12">
                        <div class="form-group">
                            <label for="tgl_mulai">Dari Tanggal:</label>
                            <input type="date" name="tgl_mulai" class="form-control shadow-sm border-left-primary" id="tgl_mulai" autofocus required oninvalid="this.setCustomValidity('Pilih Tanggal')" oninput="setCustomValidity('')">
                        </div>
                    </div>

                    <div class="col-xl-3 col-lg-3 col-md-3 col-sm-12 col-xs-12">
                        <div class="form-group">
                            <label for="tgl_selesai">Sampai Tanggal: </label>
                            <input type="date" name="tgl_selesai" class="form-control shadow-sm border-left-primary" id="tgl_selesai" autofocus required oninvalid="this.setCustomValidity('Pilih Tanggal')" oninput="setCustomValidity('')">
                        </div>
                    </div>

                    <div class="col-xl-4 col-lg-4 col-md-4 col-sm-12 col-xs-12">
                        <div class="form-group">
                            <label for="filter">Filter instansi <sup class="text-info">Opsional</sup></label>
                            <select name="filter" class="form-control shadow-sm border-left-primary" id="filter">
                                <option value="">-- Pilih Semua --</option>
                                <?php foreach ($instansi as $row) : ?>
                                    <option value="<?= $row['id']; ?>"><?= $row['nama_instansi']; ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                    </div>

                    <div class="col-xl-2 col-lg-2 col-md-2 col-sm-12 col-xs-12">
                        <button type="submit" name="btn-cek" class="btn btn-primary shadow-sm btn-cek float-left" style="margin-top: 2rem;">Cek</button>

                        <button type="submit" name="cetak-pdf" class="btn btn-outline-danger shadow-sm ml-3" style="margin-top: 2rem;">PDF <i class="fa fa-file-pdf"></i></button>
                    </div>
                </div>
            </form>
        </div>
    </div>
 <div class="card mb-3" >
 <div class="card-body mb-3">
    <?php if (!empty($data)) : ?>
        <div class="row my-1">
            <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-xs-12">
                <div class="table-responsive">
                    <table id="" class="table table-bordered table-striped" style="width: 100%;">
                        <thead>
                            <tr>
                                <th>No.</th>
                                <th>Nama Instansi</th>
                                <th>Total Pengaduan</th>
                                
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($data as $num => $row) : ?>
                                <tr>
                                    <td><?= $num + 1; ?></td>
                                    <td><?= $row['nama_instansi']; ?></td>
                                    <td><?= count($instansi_id); ?></td>
                                    <!-- <td style="width: 20%" class="status"><?= $row['status_pengaduan'] == 0 ? '<span class="badge-warning p-1 rounded-sm">Belum Diproses</span>' : ($row['status_pengaduan'] == 1 ? '<span class="badge-blue p-1 rounded-sm">Proses</span>' : ($row['status_pengaduan'] == 2 ? '<span class="badge-success p-1 rounded-sm">Selesai</span>' : '<span class="badge-danger p-1 rounded-sm">Batal</span>')) ?></td> -->
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
       
    <?php else : ?>
        <div class="row my-1">
            <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-xs-12">
                <h3 class="h3 text-center">Data tidak ditemukan!</h3>
            </div>
        </div>
    <?php endif; ?>
 </div>
        </div>
</div>
<!-- /.container-fluid -->

</div>
<!-- End of Main Content -->

<!-- Footer -->
<footer class="sticky-footer bg-white">
    <div class="container my-auto">
        <div class="copyright text-center my-auto">
            <span>Copyright &copy; <?= date('Y'); ?></span>
        </div>
    </div>
</footer>
<!-- End of Footer -->

</div>
<!-- End of Content Wrapper -->

</div>
<!-- End of Page Wrapper -->

<!-- Scroll to Top Button-->
<a class="scroll-to-top rounded" href="#page-top">
    <i class="fas fa-angle-up"></i>
</a>

<!-- Bootstrap core JavaScript-->
<script src="<?= base_url('assets/'); ?>vendor/jquery/jquery.min.js"></script>
<script src="<?= base_url('assets/'); ?>vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

<!-- Core plugin JavaScript-->
<script src="<?= base_url('assets/'); ?>vendor/jquery-easing/jquery.easing.min.js"></script>

<!-- date Format -->
<script src="<?= base_url('assets/') ?>js/jquery-dateformat.js"></script>

<!-- Custom scripts for all pages-->
<script src="<?= base_url('assets/'); ?>js/sb-admin-2.min.js"></script>

<!-- Datatables -->
<script src="<?= base_url('assets/') ?>vendor/datatables/jquery.dataTables.min.js"></script>
<script src="<?= base_url('assets/') ?>vendor/datatables/dataTables.bootstrap4.min.js"></script>
<script src="<?= base_url('assets/') ?>vendor/datatables/dataTables.rowReorder.min.js"></script>
<script src="<?= base_url('assets/') ?>vendor/datatables/dataTables.responsive.min.js"></script>


<script>
    $(document).ready(function() {

        // DataTables - ebook
        dataTables_pengaduan();

        function dataTables_pengaduan() {
            $('#table-cek').DataTable({
                responsive: true,
                "destroy": true,
                "processing": true,
                "serverSide": true,
                "order": [],

                "columnDefs": [{
                    "targets": [0, 4],
                    "orderable": false
                }],
                scrollY: "300px",
                scrollX: true,
                // scrollCollapse: false,
                // paging: true,

                "lengthMenu": [
                    [5, 10, 30, 50, -1],
                    [5, 10, 30, 50, "All"]
                ],

                "ajax": {
                    "url": "<?= base_url('menu/cek_data') ?>",
                    "type": "POST"
                },

            })
        }

        // var table = $('#table-pengaduan').DataTable()
        // table.columns([4]).visible(false);

        // Modal Box - Pengaduan
        $(document).on("click", ".btn-hapus", function() {
            let status = $(this).data('status')
            status == 0 ? status = 'belum diproses' : (status == 1 ? status = 'proses' : (status == 2 ? status = 'selesai' : status = 'gagal'))

            $(".modal-body #id_pengaduan").val($(this).data('id'))
            $(".modal-body table .judul").html($(this).data('judul'))
            $(".modal-body table .isi").html($(this).data('isi'))
            $(".modal-body table .tgl").html($(this).data('tgl'))
            $(".modal-body table .instansi").html($(this).data('instansi'))
            $(".modal-body table .status").html(status)
        })

        $(document).on("click", ".btn-hapus", function() {
            $(".modal-body #id").val($(this).data('id'))
        })

    });
</script>
</body>

</html>