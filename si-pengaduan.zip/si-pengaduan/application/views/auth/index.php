

<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="shortcut icon" href="<?= base_url('assets/'); ?>img/logo.png" rel="stylesheet">
    
    <title>Login || Aplikasi Pengaduan</title>
    <!-- Custom fonts for this template-->
    <link href="<?= base_url('assets/'); ?>vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
    <link href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i" rel="stylesheet">

    <!-- Custom styles for this template-->
    <link href="<?= base_url('assets/'); ?>css/sb-admin-2.min.css" rel="stylesheet">
    <link href="<?= base_url('assets/'); ?>css/custom.css" rel="stylesheet">
    <link href="<?= base_url('assets/'); ?>css/animate-custom.css" rel="stylesheet">
    <link href="<?= base_url('assets/'); ?>css/bg.css" rel="stylesheet">
    <link href="<?= base_url('assets/'); ?>css/style2.css" rel="stylesheet">
   
    <script type="text/javascript" src="<?= base_url('assets/'); ?>js/jquery.min.js"></script>   
     <script src="<?= base_url('assets/'); ?>js/custom.modernizr.html" type="text/javascript" ></script>

    
     

</head>

<body >
<!-- <div class="px-3 bg-light "><marquee class="" direction="left" scrollamount="12" style="font-family: impact; font-size:24px;">
        SELAMAT DATANG DI APLIKASI LAYANAN GANGGUAN JARINGAN INTERNET  -  DISKOMINFO KABUPATEN BINTAN 
</marquee></div> -->


<script type="text/javascript" src="/md5.js"></script>
    <div class="container" id="">

        <!-- Outer Row login-block py-1 -->
        <div class="">
            
             <div class=" col-sm-offset-3 col-md-offset-4" style="display:block; margin:110px auto 100px;">
                
            <div class="login-logo">
           
            
            </div>
                       <!-- <div class="card o-hidden border-0 shadow-lg">
                            <div class="card-body p-0">-->
                                <!-- Nested Row within Card Body -->
                                
                                            <!-- Show Flash_msg -->
                                            <?= $this->session->flashdata('message') ?>

                                            <!-- form login -->
                                         <!-- <div class="login-form"> -->
                                            <?= form_open('', ['class' => 'user']); ?>
                                            <a href="#"><img class="tengah" src="<?= base_url(); ?>/assets/img/login3.svg" width="250" height="150" alt="Company Logo" /></a>
                                            <!-- <form class="user" method="post" action="<?= base_url() ?>"> -->
                                               <div class="input-div one focus">
                                                <div class="form-group mb-4">
                                                    <input type="text" name="username" 
                                                    class="form-control form-control-user <?= form_error('username') ? 'is-invalid border-left-danger' : 'border-left-primary' ?>" 
                                                    value="<?= set_value('username') ?>"
                                                     placeholder="Username" 
                                                     autofocus required oninvalid="this.setCustomValidity('username gak boleh kosong')"
                                                     oninput="setCustomValidity('')" >
                                                    
                                                </div></div>

                                                <div class="input-div two focus">
                                                <div class="form-group mb-5">
                                                    <input type="password" name="pass" 
                                                    class="form-control form-control-user <?= form_error('pass') ? 'is-invalid border-left-danger' : 'border-left-primary' ?>"
                                                     placeholder="Password" 
                                                     autofocus required oninvalid="this.setCustomValidity('password gak boleh kosong')"
                                                     oninput="setCustomValidity('')" >
                                                    
                                                </div> </div>
                                                
                                                
                                                <button type="submit" class ="btn btn-login">Login </button>
                                                
                                                
                                                
                                                <?= form_close(); ?>
                                               
                                         <!-- </div> -->
                                </div>
                           <!--  </div>
                        </div>-->
                     </div>
                    </div>

                

            

    </div>

</body>

</html>